using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotateController : MonoBehaviour
{
    public GameObject planetObject;
    public Vector3 rotateAxis;

    // Update is called once per frame
    void Update()
    {
        planetObject.transform.Rotate(rotateAxis * Time.deltaTime);
    }
}
